﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ButtonActivate : MonoBehaviour
{
    private Button button;
    public GameObject container;
    void Start(){
        button = GetComponent<Button>();
        button.onClick.AddListener(Activate);
    }
    void Activate(){
        if(container.activeSelf){
            container.gameObject.SetActive(false);
        }else{
            container.gameObject.SetActive(true);
        }
    }
}
