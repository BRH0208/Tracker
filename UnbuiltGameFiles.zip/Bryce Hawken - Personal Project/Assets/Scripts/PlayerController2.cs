﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController2 : MonoBehaviour
{
    public float speed;
    private Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        Cursor.lockState = CursorLockMode.Locked;
        transform.Rotate(0,Input.GetAxis("Mouse X"),0,Space.Self);
        transform.Rotate(Input.GetAxis("Mouse Y"),0,0,Space.Self);
        rb.AddForce(Time.deltaTime * speed * Input.GetAxis("Vertical") * transform.forward);
        transform.eulerAngles = new Vector3(transform.eulerAngles.x,transform.eulerAngles.y,0);
    }
}
