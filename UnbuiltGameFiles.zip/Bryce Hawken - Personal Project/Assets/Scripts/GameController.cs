﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{

    public GameObject[] DeActivate;
    public GameObject[] Activate;
    public GameObject[] WinTexts;
    // Update is called once per frame
    public void endGame(int WinningPlayer)
    {
        foreach(GameObject container in DeActivate){
            if(container.activeSelf){
                container.gameObject.SetActive(false);
            }
        }
        foreach(GameObject container in Activate){
            if(!container.activeSelf){
                container.gameObject.SetActive(true);
            }
        }
        WinTexts[WinningPlayer].SetActive(true);
    }
}
