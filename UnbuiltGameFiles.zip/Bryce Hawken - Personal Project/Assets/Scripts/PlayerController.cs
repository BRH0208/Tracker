﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    private float speed = 80f;
    private float Maxspeed = 100f;
    public float points = 0;
    public int playerNumber = 1;
    public GameController gameManager;
    public Text pointCounter;
    public ParticleSystem particle;
    public TrailRenderer trail;
    public MeshRenderer renderer;
    public KeyCode jump;
    public KeyCode left;
    public KeyCode right;
    public Light light;
    private Color color;
    private Rigidbody rb;
    private float amt = 0;
    private float input = 0; 
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        

        // Color Setup
        color = Random.ColorHSV();
        renderer = GetComponent<MeshRenderer>();
        renderer.material.color = color; // http://gyanendushekhar.com/2018/09/16/change-material-and-its-properties-at-runtime-unity-tutorial/

        light.color = color;

        //Create new trail color
        float alpha = 1.0f;
        Gradient gradient = new Gradient();
        gradient.SetKeys(
            new GradientColorKey[] { new GradientColorKey(Color.white, 0.0f), new GradientColorKey(color, 1.0f) },
            new GradientAlphaKey[] { new GradientAlphaKey(alpha, 0.0f), new GradientAlphaKey(alpha, 1.0f) }
        ); // https://docs.unity3d.com/ScriptReference/TrailRenderer-colorGradient.html
        trail.colorGradient = gradient;
    }

    // Update is called once per frame
    void Update(){
        input = 0;
        if(Input.GetKey(left)){input-=0.9f;}
        if(Input.GetKey(right)){input+=0.9f;}
        if(Mathf.Abs(input) > 1){input = Mathf.Sign(input);} 
        if(Input.GetKeyDown(jump)){
            amt = 1f;
            particle.Play();
        }
        amt = amt - 2f * Time.deltaTime ;
        if(Input.GetKeyUp(jump)){
            amt = 0;
        }
        if(amt <= 0){
            amt = 0;
            particle.Stop();
        }
        
    }
    void OnTriggerEnter(Collider other){
        if(other.tag == "Point"){
            points++;
            pointCounter.text = "Points: " + points;
            other.gameObject.transform.position = new Vector3(Random.Range(-17,112),Random.Range(-5,75),other.gameObject.transform.position.z);
            if(points > 30){
                gameManager.endGame(playerNumber-1);
            }
        }
    }

    void FixedUpdate(){
        //Stay in Bounds
        if(transform.position.x < -17){
            transform.position = new Vector3(-17,transform.position.y,transform.position.z);
            rb.velocity = new Vector3(Mathf.Abs(rb.velocity.x)*0.5f,rb.velocity.y,rb.velocity.z);
        }
        if(transform.position.x > 112){
            transform.position = new Vector3(112,transform.position.y,transform.position.z);
            rb.velocity =  new Vector3(-Mathf.Abs(rb.velocity.x)*0.5f,rb.velocity.y,rb.velocity.z);
        }
        if(transform.position.y < -5){
            transform.position = new Vector3(transform.position.x,-5,transform.position.z);
            rb.velocity =  new Vector3(rb.velocity.x,Mathf.Abs(rb.velocity.y)*0.5f,rb.velocity.z);
        }
        if(transform.position.y > 80){
            transform.position = new Vector3(transform.position.x,80,transform.position.z);;
            rb.velocity =  new Vector3(rb.velocity.x,-Mathf.Abs(rb.velocity.y)*0.5f,rb.velocity.z);
        }

        //Max Speed
        if(rb.velocity.x > Maxspeed){
            rb.velocity = new Vector3(Maxspeed,rb.velocity.y,rb.velocity.z);
        }
        if(rb.velocity.y > Maxspeed){
            rb.velocity = new Vector3(rb.velocity.x,Maxspeed,rb.velocity.z);
        }
        if(rb.velocity.x < -Maxspeed){
            rb.velocity = new Vector3(-Maxspeed,rb.velocity.y,rb.velocity.z);
        }
        if(rb.velocity.y < -Maxspeed){
            rb.velocity = new Vector3(rb.velocity.x,-Maxspeed,rb.velocity.z);
        }

        //Fast Slow to reverse
        if(Mathf.Abs(input) > 0.2f && Mathf.Sign(input) != Mathf.Sign(rb.velocity.x)){
            rb.velocity = new Vector3(rb.velocity.x * 0.95f,rb.velocity.y,rb.velocity.z);
        }

        //Apply forces
        rb.AddForce(transform.up * amt,ForceMode.Impulse);
        rb.AddForce(new Vector3(1,0,0)*Time.deltaTime*(speed*input),ForceMode.Impulse);
    }
}
