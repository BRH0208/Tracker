﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ButtonTwo : MonoBehaviour
{
    private Button button;
    public GameObject[] DeActivate;
    void Start(){
        button = GetComponent<Button>();
        button.onClick.AddListener(Activate);
    }
    void Activate(){
        foreach(GameObject container in DeActivate){
            if(container.activeSelf){
                container.gameObject.SetActive(false);
            }else{
                container.gameObject.SetActive(true);
            }
        }
    }
}
