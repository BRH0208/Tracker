﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour
{
    public float tolerance = 15;
    public float floatHeight= 10;
    public Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.AddTorque(new Vector3(0,0,10*(Random.value-0.5f)));
    }

    // Update is called once per frame
    void Update()
    {
        if(transform.eulerAngles.z < 360-tolerance && transform.eulerAngles.z > 180){
            transform.eulerAngles = new Vector3(0, 0, 360-tolerance);
        }else if(transform.eulerAngles.z > tolerance && transform.eulerAngles.z < 180){
            transform.eulerAngles = new Vector3(0, 0, tolerance);
        }

        if(transform.position.y < -2+floatHeight){
            transform.position = new Vector3(transform.position.x,-2+floatHeight,transform.position.z);
        }else if(transform.position.y < floatHeight){
            if(transform.eulerAngles.z < 180){
                rb.AddTorque(new Vector3(0,0,-20));
            }
            if(transform.eulerAngles.z > 180){
                rb.AddTorque(new Vector3(0,0,20));
            }
            rb.AddForce(new Vector3(0,-3.6f*(transform.position.y+floatHeight),0),ForceMode.Impulse);
        }else if(transform.position.y > floatHeight){
            transform.position = new Vector3(transform.position.x,floatHeight,transform.position.z);
        }
        /*if(transform.eulerAngles.z > 45){
            transform.eulerAngles = new Vector3(0, 0, 45);
        }else if(transform.eulerAngles.z < -45){
            transform.eulerAngles = new Vector3(0, 0, -45);
        }*/
    }
}
