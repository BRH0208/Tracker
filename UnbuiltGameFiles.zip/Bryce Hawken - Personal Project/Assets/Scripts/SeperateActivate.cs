﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SeperateActivate : MonoBehaviour
{
    public GameObject[] DeActivate;
    public GameObject[] Activate;
    private Button button;
    public PlayerController[] players;
    void Start(){
        button = GetComponent<Button>();
        button.onClick.AddListener(Press);
    }

    void Press(){
        foreach(PlayerController player in players){
            player.GetComponent<PlayerController>().points = 0;
        }
        foreach(GameObject container in DeActivate){
            if(container.activeSelf){
                container.gameObject.SetActive(false);
            }
        }
        foreach(GameObject container in Activate){
            if(!container.activeSelf){
                container.gameObject.SetActive(true);
            }
        }
    }
}
